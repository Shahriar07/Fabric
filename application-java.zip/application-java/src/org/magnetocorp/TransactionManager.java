/*
SPDX-License-Identifier: Apache-2.0
*/

package org.magnetocorp;

import org.hyperledger.fabric.gateway.*;

import java.io.*;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Map;
import java.util.concurrent.TimeoutException;

import static java.nio.charset.StandardCharsets.UTF_8;

public class TransactionManager {

	private static final String ENVKEY="CONTRACT_NAME";

	// Need to pass the document name as agrument
	// as the document name used as the state key of ledger
	public static void main(String[] args) {

		String contractName="documenthandler";
		// get the name of the contract, in case it is overridden
		Map<String,String> envvar = System.getenv();
		if (envvar.containsKey(ENVKEY)){
			contractName=envvar.get(ENVKEY);
		}

		if (args.length != 3) {
			return;
		}
		String fileName = args[0];
		String newPath = args[1];
		int chunkCount = Integer.parseInt(args[2]);

		Gateway.Builder builder = Gateway.createBuilder();

		try {
			// A wallet stores a collection of identities
			Path walletPath = Paths.get("..",  "identity", "user", "isabella", "wallet");
			Wallet wallet = Wallet.createFileSystemWallet(walletPath);

			String userName = "User1@orgkona.konai.com";

			Path connectionProfile = Paths.get("..",  "gateway", "networkConnection.yaml");

		    // Set connection options on the gateway builder
			builder.identity(wallet, userName).networkConfig(connectionProfile).discovery(false);

		    // Connect to gateway using application specified parameters
			try(Gateway gateway = builder.connect()) {

				// Access PaperNet network
			    System.out.println("Use network channel: konachannel.");
			    Network network = gateway.getNetwork("konachannel");

			    // Get addressability to commercial paper contract
			    System.out.println("Use org.papernet.commercialpaper smart contract.");
				Contract contract = network.getContract(contractName, "org.papernet.commercialpaper");
				
				prepareFileFromChunks(newPath, fileName, chunkCount, contract);
			}
		} catch (GatewayException | IOException | TimeoutException | InterruptedException e) {
			e.printStackTrace();
			System.exit(-1);
		}
	}
	
	
	private static File prepareFileFromChunks(String newFileDirectoryPath, String fileName, int chunkCount, Contract contract) throws IOException, FileNotFoundException, GatewayException, TimeoutException, InterruptedException {
	
		if (fileName == null || contract == null || chunkCount < 1) {
            System.out.println("File data validation failed");
            return null;
        }
        System.out.println("newFileDirectoryPath " + newFileDirectoryPath + " fileName " + fileName);
        
        // create a new directory if not exist
        File newGeneratedFile = new File(newFileDirectoryPath);
        if (!newGeneratedFile.exists()) {
	        System.out.println("Generate newFileDirectory " + newFileDirectoryPath);
            boolean isCreated = newGeneratedFile.mkdir();
            if (!isCreated) {
                System.out.println("New directory Creation failed");
                return null;
            }
        }
        if (newGeneratedFile.exists()) {
        	System.out.println("Directory exists ");
        	Path newFilePath = Paths.get(newFileDirectoryPath,  fileName);
            File originalFile = new File(newFilePath.toString());
            if (!originalFile.exists()) {
                
                    boolean isCreated = originalFile.createNewFile();
                    if (!isCreated) {
                        System.out.println("New File Creation failed !isCreated");
                        return null;
                    }
              }
              if (originalFile.exists()) {      
				try {
                    // use a loop
                    // read bytes from the chunk files
                    // and write bytes to the new file
                    for (int count = 0; count < chunkCount; count++) {
                                        
	                    String chunkFileName =  count + "__" + fileName;
	                    // Download the document
						byte[] response2 = contract.submitTransaction("getDocument", "MagnetoCorp", chunkFileName);
						//byte[] response2 = hexStringToByteArray(responseString);
						System.out.println("Response received for " + chunkFileName);
						// TODO: JSON deserialize the response to get the byte array
						String decodedString = new String(response2, UTF_8);
						//System.out.println("Processed decodedString : " + decodedString);

						byte[] chunkBytes = hexStringToByteArray(decodedString);
						//System.out.println("Process issue transaction response." + byteArrayToString(response2));
                        writeBytesToFile(chunkBytes, originalFile, count!=0); // First time will be false to create a new file, after that append the file
                    }
                    // return the original file
                    return originalFile;
                } catch (GatewayRuntimeException e) {
                    e.printStackTrace();
                //    System.out.println("New File Creation failed");
				//	throw e;
                }
            }
        }
        System.out.println("New File Creation failed newGeneratedFile");
        return null;

    }
    
    
    public static void writeBytesToFile(byte[] fileBytes, File file, boolean append) {
        OutputStream opStream = null;
        try {
            if (!file.exists()) {
                file.createNewFile();
            }
            opStream = new FileOutputStream(file, append);
            opStream.write(fileBytes);
            opStream.flush();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if (opStream != null) opStream.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }
	
	
	
	private static String byteArrayToString(byte[] bytes) {
	
		char [] HEX_ARRAY = "0123456789ABCDEF".toCharArray();
		char [] hexChars = new char[bytes.length * 2];
		for (int j = 0; j < bytes.length; j++) {
			int v = bytes[j] & 0xFF;
			hexChars[j * 2] = HEX_ARRAY[v >>> 4];
			hexChars[j * 2 + 1] = HEX_ARRAY[v & 0x0F];
		}
		return new String(hexChars);
	}
	
	    public static byte[] hexStringToByteArray(String s) {
        int len = s.length();
        byte[] data = new byte[len / 2];
        for (int i = 0; i < len; i += 2) {
            data[i / 2] = (byte) ((Character.digit(s.charAt(i), 16) << 4)
                    + Character.digit(s.charAt(i + 1), 16));
        }
        return data;
    }
	

}
