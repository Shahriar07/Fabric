package org.magnetocorp;

import java.io.*;
import java.net.URLConnection;
import java.util.Arrays;

/**
 * @author H. M. Shahriar (h.m.shahriar@konasl.com)
 * @since 10/2/2019 11:22
 */
public class FileHandler {

    public static void main(String[] args) {
        String path = "E:\\Projects\\BlockChain\\HyperledgerFabric\\Resources\\fabric-samples-master\\commercial-paper\\organization\\magnetocorp\\application-java";
        File file = new File(path + "\\ssl-cert.crt");
//        String path = "E:\\Projects\\BlockChain\\HyperledgerFabric\\Resources\\fabric-samples-master\\commercial-paper\\organization\\magnetocorp\\application-java\\target\\classes\\org\\magnetocorp";
//        File file = new File(path + "\\AddToWallet.class");

        byte[] bytes = readbinaryDataFromFile(file);

        int chunkCount = writeChunkOfFile(bytes, 500, path, file.getName());
//        DatatypeConverter.parseHexBinary(bytes);

        prepareFileFromChunks(path,file.getName(),chunkCount);

        //readStringDataFromFile(file);
//        URLConnection connection = null;
//        try {
//            connection = file.toURI().toURL().openConnection();
//            String mimeType = connection.getContentType();
//            System.out.println("mimeType is:" + mimeType);
//        } catch (IOException e) {
//            e.printStackTrace();
//        }


    }

    public static byte[] readbinaryDataFromFile(File file) {
        try {
            //Instantiate the input stread
            InputStream insputStream = new FileInputStream(file);
            long length = file.length();
            byte[] bytes = new byte[(int) length];

            insputStream.read(bytes);
            insputStream.close();

            //String s = byteArrayToString(bytes);
            //Print the byte data into string format
            //System.out.println(s);
            return bytes;
        } catch (Exception e) {
            System.out.println("Error is:" + e.getMessage());
            return null;
        }
    }


    public static int writeChunkOfFile(byte[] fileBytes, int chunksize, String path, String fileName) {
        if (fileBytes.length == 0 || chunksize < 1) {
            System.out.println("File data validation failed");
            return 0;
        }
        System.out.println("File size " + fileBytes.length);
        int start = 0;
        int counter = 0;
        while(start < fileBytes.length) {
            File fileChunk = new File(path + "//" + counter + "__" + fileName);
            int end = Math.min(fileBytes.length, start + chunksize);
            writeBytesToFile(Arrays.copyOfRange(fileBytes, start, end), fileChunk, false);
            start += chunksize;
            ++counter;
        }
        return counter;
    }

    public static void writeBytesToFile(byte[] fileBytes, File file, boolean append) {
        OutputStream opStream = null;
        try {
            if (!file.exists()) {
                file.createNewFile();
            }
            opStream = new FileOutputStream(file, append);
            opStream.write(fileBytes);
            opStream.flush();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if (opStream != null) opStream.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }

    public static boolean checkIfTheFirstChunkExists(String path, String fileName){
        File file = new File(path + "\\0__" + fileName);
        if (!file.exists()) {
            System.out.println("Chunk file not exist");
            return false;
        }
        return true;
    }

    private static File prepareFileFromChunks(String path, String fileName, int chunkCount) {
        // Check if the first chunk exists
        boolean fileExistsFlag = checkIfTheFirstChunkExists(path, fileName);
        if (!fileExistsFlag) {
            return null;
        }

        // create a new directory
        String directoryName = path + "\\Generated";
        File newGeneratedFile = new File(directoryName);
        if (!newGeneratedFile.exists()) {
            boolean isCreated = newGeneratedFile.mkdir();
            if (!isCreated) {
                System.out.println("New File Creation failed");
                return null;
            }
        }
        if (newGeneratedFile.exists()) {
            File originalFile = new File(directoryName + "\\" + fileName);
            if (!originalFile.exists()) {
                try {
                    boolean isCreated = originalFile.createNewFile();
                    if (!isCreated) {
                        System.out.println("New File Creation failed");
                        return null;
                    }

                    // use a loop
                    // read bytes from the chunk files
                    // and write bytes to the new file
                    for (int count = 0; count < chunkCount; count++) {
                        File file = new File(path + "\\" + count + "__" + fileName);
                        if (!file.exists()) {
                            System.out.println("Chunk file not exist");
                            return null;
                        }
                        byte[] chunkBytes = readbinaryDataFromFile(file);
                        writeBytesToFile(chunkBytes, originalFile, true);
                    }
                    // return the original file
                    return originalFile;
                } catch (IOException e) {
                    e.printStackTrace();
                    System.out.println("New File Creation failed");
                    return null;
                }
            }
        }
        return null;

    }

    private static void readStringDataFromFile(File file) {
        BufferedReader br = null;
        try {
            br = new BufferedReader(new FileReader(file));
            String st;
            while ((st = br.readLine()) != null)
                System.out.println(st);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static String byteArrayToString(byte[] bytes) {
//        StringBuilder hex = new StringBuilder(ba.length * 2);
        char[] HEX_ARRAY = "0123456789ABCDEF".toCharArray();
        char[] hexChars = new char[bytes.length * 2];
        for (int j = 0; j < bytes.length; j++) {
            int v = bytes[j] & 0xFF;
            hexChars[j * 2] = HEX_ARRAY[v >>> 4];
            hexChars[j * 2 + 1] = HEX_ARRAY[v & 0x0F];
        }
        return new String(hexChars);
    }


    public static byte[] hexStringToByteArray(String s) {
        int len = s.length();
        byte[] data = new byte[len / 2];
        for (int i = 0; i < len; i += 2) {
            data[i / 2] = (byte) ((Character.digit(s.charAt(i), 16) << 4)
                    + Character.digit(s.charAt(i + 1), 16));
        }
        return data;
    }
}
