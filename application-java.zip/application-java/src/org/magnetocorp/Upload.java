/*
SPDX-License-Identifier: Apache-2.0
*/

package org.magnetocorp;

import java.io.*;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Map;
import java.util.concurrent.TimeoutException;

import org.hyperledger.fabric.gateway.Contract;
import org.hyperledger.fabric.gateway.Gateway;
import org.hyperledger.fabric.gateway.GatewayException;
import org.hyperledger.fabric.gateway.Network;
import org.hyperledger.fabric.gateway.Wallet;

import static java.nio.charset.StandardCharsets.UTF_8;

public class Upload {

	private static final String ENVKEY="CONTRACT_NAME";

	public static void main(String[] args) {
	
		if (args.length != 1) {
			System.out.println("Argument type mismatch. Add the file path as agrument to upload a document");
			return;
		}
		String fileName = args[0];
        File file = new File(fileName);
        
       
		String contractName="documenthandler";
		// get the name of the contract, in case it is overridden
		Map<String,String> envvar = System.getenv();
		if (envvar.containsKey(ENVKEY)){
			contractName=envvar.get(ENVKEY);
		}

		Gateway.Builder builder = Gateway.createBuilder();

		try {
			// A wallet stores a collection of identities
			Path walletPath = Paths.get("..",  "identity", "user", "isabella", "wallet");
			Wallet wallet = Wallet.createFileSystemWallet(walletPath);

			String userName = "User1@orgkona.konai.com";

			Path connectionProfile = Paths.get("..",  "gateway", "networkConnection.yaml");

		    // Set connection options on the gateway builder
			builder.identity(wallet, userName).networkConfig(connectionProfile).discovery(false);

		    // Connect to gateway using application specified parameters
			try(Gateway gateway = builder.connect()) {

				// Access PaperNet network
			    System.out.println("Use network channel: konachannel.");
			    Network network = gateway.getNetwork("konachannel");

			    // Get addressability to commercial paper contract
			    System.out.println("Use org.papernet.commercialpaper smart contract.");
				Contract contract = network.getContract(contractName, "org.papernet.commercialpaper");

			    // Issue commercial paper
				System.out.println("Submit commercial paper issue transaction.");
		        long chunkCount = writeChunkOfFile(file, 5000, contract); // file, maxchunk size in bytes, contract

				// Process response
				System.out.println("Total number of chunks : " + chunkCount);
			}
		} catch (GatewayException | IOException | TimeoutException | InterruptedException e) {
			e.printStackTrace();
			System.exit(-1);
		}
	}
    
    
    private static long writeChunkOfFile(File file, int chunksize, Contract contract) throws IOException, FileNotFoundException, GatewayException, TimeoutException, InterruptedException {
        if (file == null || chunksize < 1) {
            System.out.println("File data validation failed");
            return 0;
        }
        FileInputStream inputStream = new FileInputStream(file);
        long length = file.length();
        
        String path = file.getParent();
        String fileName = file.getName();
        System.out.println("File size " + file.length());
        long start = 0;
        long counter = 0;
        while(start < length) {
        	String chunkFileName =  counter + "__" + fileName;
            long end = Math.min(length, start + chunksize);
            byte[] buffer = new byte[(int)(end-start)];
            long readBufferSize = inputStream.read(buffer);
            byte[] response = contract.submitTransaction("addDocument", "MagnetoCorp", chunkFileName, byteArrayToString(buffer));
			System.out.println(chunkFileName + " transaction response : " + new String(response, UTF_8));
            start += chunksize;
            ++counter;
        }
        inputStream.close();
        return counter;
    }
	
	private static String byteArrayToString(byte[] bytes) {
	
		char [] HEX_ARRAY = "0123456789ABCDEF".toCharArray();
		char [] hexChars = new char[bytes.length * 2];
		for (int j = 0; j < bytes.length; j++) {
			int v = bytes[j] & 0xFF;
			hexChars[j * 2] = HEX_ARRAY[v >>> 4];
			hexChars[j * 2 + 1] = HEX_ARRAY[v & 0x0F];
		}
		return new String(hexChars);
	}

}
