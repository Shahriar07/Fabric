/*
 *  SPDX-License-Identifier: Apache-2.0
 */
package org.example;

import org.hyperledger.fabric.contract.Context;
import org.hyperledger.fabric.shim.ChaincodeStub;

class DocumentStorageContext extends Context {

    public DocumentStorageContext(ChaincodeStub stub) {
        super(stub);
    }

}