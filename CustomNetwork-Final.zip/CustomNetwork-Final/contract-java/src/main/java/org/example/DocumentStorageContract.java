/*
SPDX-License-Identifier: Apache-2.0
*/
package org.example;


import org.hyperledger.fabric.contract.Context;
import org.hyperledger.fabric.contract.ContractInterface;
import org.hyperledger.fabric.contract.annotation.*;
import org.hyperledger.fabric.shim.ChaincodeStub;
import org.hyperledger.fabric.shim.ledger.CompositeKey;

import java.util.logging.Logger;

/**
 * A custom context provides easy access to list of all commercial papers
 */

/**
 * Define commercial paper smart contract by extending Fabric Contract class
 */
@Contract(name = "org.papernet.commercialpaper", info = @Info(title = "MyAsset contract", description = "", version = "0.0.1", license = @License(name = "SPDX-License-Identifier: ", url = ""), contact = @Contact(email = "java-contract@example.com", name = "java-contract", url = "http://java-contract.me")))
@Default
public class DocumentStorageContract implements ContractInterface {

    // use the classname for the logger, this way you can refactor
    private final static Logger LOG = Logger.getLogger(DocumentStorageContract.class.getName());

    @Override
    public Context createContext(ChaincodeStub stub) {
        return new DocumentStorageContext(stub);
    }

    public DocumentStorageContract() {

    }

    /**
     * Define a custom context for commercial paper
     */

    /**
     * Instantiate to perform any setup of the ledger that might be required.
     *
     * @param {Context} ctx the transaction context
     */
    @Transaction
    public void instantiate(DocumentStorageContext ctx) {
        // No implementation required with this example
        // It could be where data migration is performed, if necessary
        LOG.info("No data migration to perform");
    }

    /**
     * Upload a document bytes
     *
     * @param {Context} ctx the transaction context
     * @param {String}  issuer document uploader name
     * @param {String} documentName name of the document
     * @param {String} documentBytes content of the document
     */
    @Transaction
    public boolean addDocument(DocumentStorageContext ctx, String issuer, String documentName, String documentBytes) {

        System.out.println("Context : " + ctx);
        //System.out.println("documentBytes : "+ documentBytes);

        ChaincodeStub stub = ctx.getStub();
        CompositeKey ledgerKey = stub.createCompositeKey(issuer, documentName);
        System.out.println("ledgerKey is " + ledgerKey);
        byte[] bytes = hexStringToByteArray(documentBytes);
        if(bytes.length > 0) {
	        ctx.getStub().putState(ledgerKey.toString(), bytes);
        }
        return true;
    }

    /**
     * Retrieves a document bytes
     *
     * @param {Context} ctx the transaction context
     * @param {String}  issuer document uploader name
     * @param {Integer} documentName name of the document
     */
    @Transaction
    public String getDocument(DocumentStorageContext ctx, String issuer, String documentName) {
        CompositeKey ledgerKey = ctx.getStub().createCompositeKey(issuer, documentName);

        System.out.println("ledgerKey is " + ledgerKey);
        System.out.println("LedgerKey " + ledgerKey.toString());
        byte[] data = ctx.getStub().getState(ledgerKey.toString());
        if (data != null && data.length > 0) {
        		String dataHexBytes = byteArrayToString(data);
              System.out.println("Data is " + dataHexBytes);
//            State state = this.deserializer.deserialize(data);
            return dataHexBytes;
        } else {
            return null;
        }
    }
    

	/**
	* Convert a byte array to a hex string
	*
	* @param {byte[]} byte array 
	*/    
    private String byteArrayToString(byte[] bytes) {
	
		char [] HEX_ARRAY = "0123456789ABCDEF".toCharArray();
		char [] hexChars = new char[bytes.length * 2];
		for (int j = 0; j < bytes.length; j++) {
			int v = bytes[j] & 0xFF;
			hexChars[j * 2] = HEX_ARRAY[v >>> 4];
			hexChars[j * 2 + 1] = HEX_ARRAY[v & 0x0F];
		}
		return new String(hexChars);
	}
	
	/**
	* Converts hex string to a byte array
	*
	* @param {byte[]} byte array 
	*/
	private byte[] hexStringToByteArray(String s) {
		int len = s.length();
		byte[] data = new byte[len / 2];
		for(int i=0; i < len; i +=2) {
			data[i / 2] = (byte) ((Character.digit(s.charAt(i), 16) << 4)
						+ Character.digit(s.charAt(i+1), 16));
		}
		return data;
	}
}
