/*
SPDX-License-Identifier: Apache-2.0
*/

package org.magnetocorp;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import org.hyperledger.fabric.gateway.GatewayException;
import org.hyperledger.fabric.gateway.Wallet;
import org.hyperledger.fabric.gateway.Wallet.Identity;

public class AddToWallet {

	public static void main(String[] args) {
		try {
			// A wallet stores a collection of identities
			Path walletPath = Paths.get("..", "identity", "user", "isabella", "wallet");
			Wallet wallet = Wallet.createFileSystemWallet(walletPath);

	        // Location of credentials to be stored in the wallet
			Path credentialPath = Paths.get("..", "crypto-config",
					"peerOrganizations", "orgkona.konai.com", "users", "User1@orgkona.konai.com", "msp");
			Path certificatePem = credentialPath.resolve(Paths.get("signcerts",
					"User1@orgkona.konai.com-cert.pem"));
			Path privateKey = credentialPath.resolve(Paths.get("keystore",
					"0daf5533b15b6f7fc7fd1ee674278ed563375aaccadffdb3e948e17540d9d74a_sk"));

		       // Load credentials into wallet
			String identityLabel = "User1@orgkona.konai.com";
			Identity identity = Identity.createIdentity("OrgKonaMSP", Files.newBufferedReader(certificatePem), Files.newBufferedReader(privateKey));

			wallet.put(identityLabel, identity);

		} catch (IOException e) {
			System.err.println("Error adding to wallet");
			e.printStackTrace();
		}
	}

}
