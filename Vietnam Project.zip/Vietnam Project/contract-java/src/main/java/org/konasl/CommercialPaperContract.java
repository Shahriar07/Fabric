/*
SPDX-License-Identifier: Apache-2.0
*/
package org.konasl;


import org.hyperledger.fabric.contract.Context;
import org.hyperledger.fabric.contract.ContractInterface;
import org.hyperledger.fabric.contract.annotation.*;
import org.hyperledger.fabric.shim.ChaincodeStub;
import org.hyperledger.fabric.shim.ledger.CompositeKey;
import org.konasl.ledgerapi.State;
import org.konasl.util.Utility;

import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.logging.Logger;

import static org.konasl.util.Utility.hexStringToByteArray;

/**
 * A custom context provides easy access to list of all commercial papers
 */

/**
 * Define commercial paper smart contract by extending Fabric Contract class
 */

@Contract(name = "org.konasl.documentcontainer", info = @Info(title = "Document Container Contract", description = "", version = "0.0.1", license = @License(name = "SPDX-License-Identifier: ", url = ""), contact = @Contact(email = "info_ksl@konasl.com", name = "KSL Admin", url = "https://konasl.com")))
@Default
public class CommercialPaperContract implements ContractInterface {

    // use the classname for the logger, this way you can refactor
    private final static Logger LOG = Logger.getLogger(CommercialPaperContract.class.getName());

    @Override
    public Context createContext(ChaincodeStub stub) {
        return new DocumentHolderContext(stub);
    }

    public CommercialPaperContract() {
    }

    /**
     * Define a custom context for commercial paper
     */

    /**
     * Instantiate to perform any setup of the ledger that might be required.
     *
     * @param {Context} ctx the transaction context
     */
    @Transaction
    public void instantiate(DocumentHolderContext ctx) {
        // No implementation required with this konasl
        // It could be where data migration is performed, if necessary
        LOG.info("No data migration to perform");
    }

    /**
     * Upload the metadata for a new document
     *
     * @param {Context} ctx the transaction context
     * @param {String}  issuer commercial paper issuer
     * @param {Integer} paperNumber paper number for this issuer
     * @param {String}  issueDateTime paper issue date
     * @param {String}  maturityDateTime paper maturity date
     * @param {Integer} faceValue face value of paper
     */

    @Transaction
    public DocumentContainer uploadMetadata(DocumentHolderContext ctx, String fileName, String fileHash, String chunkCount) {

//        System.out.println("Context : " + ctx);
//        //System.out.println("documentBytes : "+ documentBytes);
//
//        ChaincodeStub stub = ctx.getStub();
//        CompositeKey ledgerKey = stub.createCompositeKey(chunkFileName, uploadToken);
//        System.out.println("ledgerKey is " + ledgerKey);
//        byte[] bytes = hexStringToByteArray(documentBytes);
//        if(bytes.length > 0) {
//            ctx.getStub().putState(ledgerKey.toString(), bytes);
//        }
//        return true;


        System.out.println(ctx);
        // Generate the token
        String token = null;
        try {
            token = generateUploadToken(fileName, fileHash, chunkCount);
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
            return null;
        }
        int count = Integer.parseInt(chunkCount);
        // Generate the chunkKeyList
        ArrayList<String> chunkKeyList = generateChunkKeyList(fileName, fileHash, count);

        // create an instance of the paper
        DocumentContainer document = DocumentContainer.createInstance(fileName, fileHash, count, token, chunkKeyList);

        System.out.println(document);
        // Add the document to the list of all similar documents in the ledger
        // world state
        ctx.documentList.addDocument(document);

        // Return a serialized document container to the caller of smart contract
        return document;
    }

    /**
     * Generates an upload token to initiate the upload operation
     * This token will be used later to identify the document
     *
     * @param fileName
     * @param fileHash
     * @param chunkCount
     * @return
     * @throws NoSuchAlgorithmException
     */
    private String generateUploadToken(String fileName, String fileHash, String chunkCount) throws NoSuchAlgorithmException {
        return Utility.prepareSha256Hash(fileName + fileHash + chunkCount);
    }


    /**
     * Generates an upload token to initiate the upload operation
     * This token will be used later to identify the document
     *
     * @param fileName
     * @param fileHash
     * @param count
     * @return
     * @throws NoSuchAlgorithmException
     */
    private ArrayList<String> generateChunkKeyList(String fileName, String fileHash, int count) {
        ArrayList<String> keyList = new ArrayList<>();
        for (int i = 0; i < count; i++) {
            keyList.add(fileName + fileHash.substring(0, 4) + i);
        }
        return keyList;
    }

    /**
     * Add chunk to a document
     *
     * @param {Context} ctx the transaction context
     * @param {String}  issuer commercial paper issuer
     * @param {Integer} paperNumber paper number for this issuer
     * @param {String}  issueDateTime paper issue date
     * @param {String}  maturityDateTime paper maturity date
     * @param {Integer} faceValue face value of paper
     */

    @Transaction
    public DocumentContainer uploadDocument(DocumentHolderContext ctx, String chunkFileName, String documentBytes, String uploadToken) {

//        System.out.println("Context : " + ctx);
        //System.out.println("documentBytes : "+ documentBytes);

//        ChaincodeStub stub = ctx.getStub();
//        CompositeKey ledgerKey = stub.createCompositeKey(chunkFileName, uploadToken);
//        System.out.println("ledgerKey is " + ledgerKey);
//        byte[] bytes = hexStringToByteArray(documentBytes);
//        if (bytes.length > 0) {
//            ctx.getStub().putState(ledgerKey.toString(), bytes);
//        }
//        return true;


        System.out.println(ctx);

        // create an instance of the paper
        DocumentContainer document = DocumentContainer.createInstance(issuer, paperNumber, issueDateTime, maturityDateTime,
                faceValue, issuer, "");

        // Smart contract, rather than paper, moves paper into ISSUED state
        document.setIssued();

        // Newly issued paper is owned by the issuer
        document.setOwner(issuer);

        System.out.println(document);
        // Add the paper to the list of all similar commercial papers in the ledger
        // world state
        ctx.documentList.addDocument(document);

        // Must return a serialized paper to caller of smart contract
        return document;
    }


    /**
     * Retrieves a document bytes
     *
     * @param {Context} ctx the transaction context
     * @param {String}  issuer document uploader name
     * @param {Integer} documentName name of the document
     */
    @Transaction
    public String getDocument(DocumentHolderContext ctx, String issuer, String documentName) {
        CompositeKey ledgerKey = ctx.getStub().createCompositeKey(issuer, documentName);

        System.out.println("ledgerKey is " + ledgerKey);
        System.out.println("LedgerKey " + ledgerKey.toString());
        byte[] data = ctx.getStub().getState(ledgerKey.toString());
        if (data != null && data.length > 0) {
            String dataHexBytes = Utility.byteArrayToString(data);
            System.out.println("Data is " + dataHexBytes);
//            State state = this.deserializer.deserialize(data);
            return dataHexBytes;
        } else {
            return null;
        }
    }
}
