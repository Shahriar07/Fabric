package com.konasl.documenthandler.protocol.services.upload;

import com.konasl.documenthandler.auth.AuthUser;
import com.konasl.documenthandler.constants.NetworkConstants;
import com.konasl.documenthandler.protocol.ResponseCodeEnum;
import com.konasl.documenthandler.protocol.RestResponse;
import com.konasl.documenthandler.util.Utility;
import org.hyperledger.fabric.gateway.Contract;
import org.hyperledger.fabric.gateway.ContractException;
import org.hyperledger.fabric.gateway.GatewayException;
import org.hyperledger.fabric.gateway.Network;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.io.InputStream;
import java.security.NoSuchAlgorithmException;
import java.util.concurrent.TimeoutException;

import static com.konasl.documenthandler.util.Utility.byteArrayToString;
import static java.nio.charset.StandardCharsets.UTF_8;

@Service
public class UploadServiceImpl implements UploadService{

    @Autowired
    private AuthUser authUser;

    @Override
    public RestResponse uploadDocument(MultipartFile file) {

        if (file == null) {
            System.out.println("Argument type mismatch. Add the file path as agrument to upload a document");
            return new RestResponse(ResponseCodeEnum.DOCUMENT_DATA_VERIFICATION_FAILED);
        }

        Network network = authUser.authUserandGenerateNetwork();
        if (network == null) {
            System.out.println("Network generation failed");
            return new RestResponse(ResponseCodeEnum.BLOCKCHAIN_NETWORK_CONNECTION_FAILED);
        }

        try {
            // Get addressability to commercial paper contract
            System.out.println("Use org.papernet.commercialpaper smart contract.");
            Contract contract = network.getContract(NetworkConstants.CHAIN_CODE_NAME, "org.papernet.commercialpaper");

            // Issue commercial paper
            System.out.println("Submit commercial paper issue transaction.");
            RestResponse uploadResponse = uploadChunkOfFile(file, NetworkConstants.FILE_CHUNK_SIZE, contract); // file, maxchunk size in bytes, contract
            System.out.println("Total number of chunks : " + uploadResponse.getData());
            return uploadResponse;
//
//            if (ResponseCodeEnum.SUCCESS.getCode().equals(uploadResponse.getResponseCode())) {
//                // Process response
//                System.out.println("Total number of chunks : " + uploadResponse.getData());
//                return new RestResponse(ResponseCodeEnum.SUCCESS);
//            }

        } catch (GatewayException | IOException | TimeoutException | InterruptedException | NoSuchAlgorithmException e) {
            e.printStackTrace();
            return new RestResponse(ResponseCodeEnum.FAILURE, e.getMessage());
        }
    }

    /**
     * Upload the file in chunks if the file size is larger than the chunk size
     * performs multiple transaction to the blockchain to upload the file
     *
     * @param file
     * @param chunksize
     * @param contract
     * @return
     * @throws IOException
     * @throws GatewayException
     * @throws TimeoutException
     * @throws InterruptedException
     */
    private RestResponse uploadChunkOfFile(MultipartFile file, int chunksize, Contract contract) throws IOException, GatewayException, TimeoutException, InterruptedException, NoSuchAlgorithmException {
        if (file == null || chunksize < 1) {
            System.out.println("File data validation failed");
            return new RestResponse(ResponseCodeEnum.FAILURE, ResponseCodeEnum.DOCUMENT_DATA_VERIFICATION_FAILED);
        }
        InputStream inputStream = file.getInputStream();
        long length = file.getSize();

        String fileName = file.getName();
        System.out.println("File size " + length);
        String fileHash = Utility.prepareSha256HashofMultipartFile(file);

        long chunkCount = (length / chunksize) + 1;
        // input the metadata to the network
        String uploadToken = uploadFileMetadataToTheBlockchain(fileName, chunkCount, fileHash, contract);
        if (uploadToken == null) {
            return new RestResponse(ResponseCodeEnum.FAILURE, ResponseCodeEnum.DOCUMENT_DATA_VERIFICATION_FAILED);
        }

        long start = 0;
        long counter = 0;
        while (start < length) {
            String chunkFileName = counter + "__" + fileName;
            long end = Math.min(length, start + chunksize);
            byte[] buffer = new byte[(int) (end - start)];
            long readBufferSize = inputStream.read(buffer);
            if (readBufferSize > 0) {
                byte[] response = contract.submitTransaction("addDocument", chunkFileName, byteArrayToString(buffer), uploadToken);
                System.out.println(chunkFileName + " transaction response : " + new String(response, UTF_8));
            }
            start += chunksize;
            ++counter;
        }
        inputStream.close();
        return new RestResponse(ResponseCodeEnum.SUCCESS);
    }

    /**
     * Upload file metadata to the blockchain
     * Contract prepares an token to upload the chunk
     *
     * @param fileName
     * @param chunkCount
     * @param fileHash
     * @param contract
     * @return Token to upload the file chunks to the contract
     * @throws InterruptedException
     * @throws TimeoutException
     * @throws ContractException
     */
    private String uploadFileMetadataToTheBlockchain(String fileName, long chunkCount, String fileHash, Contract contract) throws InterruptedException, TimeoutException, ContractException {
        //validate input data
        if (fileName == null || "".equals(fileName)) {
            System.out.println("Invalid File Name");
            return null;
        }
        if (fileHash == null || "".equals(fileHash)) {
            System.out.println("Invalid File Hash");
            return null;
        }
        if (contract == null || chunkCount < 1) {
            System.out.println("Invalid contract or chunk count");
            return null;
        }
        //Send metadata to the blockchain
        byte[] response = contract.submitTransaction(NetworkConstants.UPLOAD_METADATA_FUNCTION_NAME, fileName, fileHash, String.valueOf(chunkCount));
        if (response.length == 0) {
            return null;
        }
        return new String(response, UTF_8);
    }
}
