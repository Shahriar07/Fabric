package com.konasl.documenthandler;

import com.konasl.documenthandler.auth.AuthUser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DocumentHandlerApplication {

	public static void main(String[] args) {
		SpringApplication.run(DocumentHandlerApplication.class, args);
	}

}
