package com.konasl.documenthandler.constants;

/**
 * Contains the constant values for the fabric network
 *
 * @author H. M. Shahriar (h.m.shahriar@konasl.com)
 * @since 10/10/2019 15:16
 */
public class NetworkConstants {

    public static final String CHANNEL_NAME = "konachannel";
    public static final String CHAIN_CODE_NAME = "documenthandler";
    public static final String DOWNLOAD_EVENT_NAME = "GetDocument";
    public static final String UPLOAD_EVENT_NAME = "AddDocument";

    // contract method name
    public static final String UPLOAD_METADATA_FUNCTION_NAME = "uploadMetadata";
    public static final String QUERY_METADATA_FUNCTION_NAME = "queryMetadata";


//    public static final int FILE_CHUNK_SIZE = 5120;                     // File Chunk Size to split a large file
    public static final int FILE_CHUNK_SIZE = 10240;                     // File Chunk Size to split a large file

    public static final int EVENT_LISTENER_TIME = 600;                  // Waiting time to wait for an event
    public static final int THREAD_SLEEP_TIME_FOR_EVENT = 1000;         // In milliseconds

    // User private key file name, will be stored in keystore directory
    public static final String KEY_FILE_NAME = "201038b134711192ed1e5c6ea8ab0e05e57fe5ceaa1c62e4a586318aec220b9c_sk";


}
